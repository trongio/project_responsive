# bootcamp-scss

### Install dependencies

`npm install`

### Run Development Environment

`npm run development`

### Run Server

`npm run server`

*Please run all commands in separate console windows*.

